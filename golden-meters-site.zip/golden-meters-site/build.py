import base64,io,json,re
from PIL import Image
A='/home/claude/proj/app/public/assets/'
def uri(im,fmt='WEBP',q=80):
    b=io.BytesIO(); im.save(b,fmt,quality=q,method=6) if fmt=='WEBP' else im.save(b,fmt,optimize=True)
    return f"data:image/{fmt.lower()};base64,"+base64.b64encode(b.getvalue()).decode()
t=open('template.html',encoding='utf-8').read()
imgs={}
def img(key,w=1400):
    p=[A+key+e for e in('.webp','.jpg','.png') if __import__('os').path.exists(A+key+e)][0]
    im=Image.open(p).convert('RGB')
    tw=min(w,im.width*2)
    if tw!=im.width: im=im.resize((tw,round(im.height*tw/im.width)),Image.LANCZOS)
    from PIL import ImageFilter,ImageEnhance
    im=im.filter(ImageFilter.UnsharpMask(radius=1.6,percent=60,threshold=3))
    im=ImageEnhance.Color(ImageEnhance.Contrast(im).enhance(1.05)).enhance(1.04)
    return uri(im,'WEBP',82)
keys=sorted(set(re.findall(r"'((?:villa|green|apartments)/[a-z\-]+)'",t))|set(re.findall(r"data-k=\"([\w/\-]+)\"",t)))
for k in keys: imgs[k]=img(k,1024 if k.startswith('brand') else 1700)
logo=Image.open(A+'brand/logo.png').convert('RGBA').crop((0,0,105,100)); crown=uri(logo,'PNG')
t=re.sub(r"\{\{IMG:([\w/\-]+)\}\}",lambda m:imgs[m.group(1)],t).replace('{{CROWN}}',crown)
t=t.replace('/*I*/',json.dumps(imgs,separators=(',',':')))
open('index.html','w',encoding='utf-8').write(t); print(len(keys),'imgs',round(len(t)/1e6,2),'MB')
